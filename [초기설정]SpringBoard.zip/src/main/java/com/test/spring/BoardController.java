package com.test.spring;

public class BoardController {

}

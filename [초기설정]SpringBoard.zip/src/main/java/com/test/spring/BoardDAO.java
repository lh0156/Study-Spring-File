package com.test.spring;

public interface BoardDAO {

}

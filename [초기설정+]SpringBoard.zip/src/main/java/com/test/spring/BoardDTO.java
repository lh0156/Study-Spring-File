package com.test.spring;

public class BoardDTO {

}

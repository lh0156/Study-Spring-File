package com.test.spring;

public interface BoardService {

}

package com.test.memo;

import lombok.Data;

@Data
public class MemoDTO {
	
	private String seq;
	private String name;
	private String memo;
	private String regdate;

}

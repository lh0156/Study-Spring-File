package com.test.bootstart;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;


//Spring Boot의 시작 클래스
//현재 파일이 있는 패키지 > <context:component-scan base-package="com.test.bootstart" />
@SpringBootApplication
public class BootStartApplication {

	//main 시작 -> Spring Boot 시작
	public static void main(String[] args) {
		SpringApplication.run(BootStartApplication.class, args);
	}

}

package com.test.bootjsp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootJspApplicationTests {

	@Test
	void contextLoads() {
	}

}

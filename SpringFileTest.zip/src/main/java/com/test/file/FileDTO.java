package com.test.file;

import lombok.Data;

@Data
public class FileDTO {
	private String seq;
	private String filename;
	private String orgfilename;
	private String bseq;
}

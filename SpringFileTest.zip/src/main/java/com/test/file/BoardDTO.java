package com.test.file;

import lombok.Data;

@Data
public class BoardDTO {

	private String seq;
	private String subject;
	private String name;
	private String regdate;
	private String filename;
	private String orgfilename;
	
}

package com.test.bootmybatis.domain;

import lombok.Data;

@Data
public class AddressDTO {
	
	private String seq;
	private String name;
	private String age;
	private String tel;
	private String address;

}

package com.test.spring.di04;

public class DDD {

	public void run() {
		
		System.out.println("do something..");
		
	}

}

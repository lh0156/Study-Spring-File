package com.test.spring.di05;

public class DDD {

	public void run() {
		
		System.out.println("do something..");
		
	}

}

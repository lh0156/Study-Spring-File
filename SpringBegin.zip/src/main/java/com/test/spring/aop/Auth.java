package com.test.spring.aop;

public class Auth {
	
	public void auth() {
		
		//인증 티켓 -> 확인
		System.out.println("인증받은 사용자인지 검사합니다.");
		
	}

}

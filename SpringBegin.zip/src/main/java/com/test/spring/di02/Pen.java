package com.test.spring.di02;

public class Pen {
	
	 public void draw() {
		 
		 System.out.println("펜으로 그림을 그립니다.");
		 
	 }

}

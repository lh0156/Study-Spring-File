package com.test.spring.di01;

public class Brush {
	
	public void draw() {
		 
		 System.out.println("붓으로 그림을 그립니다.");
		 
	 }

}

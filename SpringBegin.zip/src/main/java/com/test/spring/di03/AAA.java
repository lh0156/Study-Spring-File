package com.test.spring.di03;

public class AAA {

	public void run() {
		
		BBB b = new BBB();
		b.run();
		
	}

}

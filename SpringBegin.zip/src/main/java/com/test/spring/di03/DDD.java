package com.test.spring.di03;

public class DDD {

	public void run() {
		
		System.out.println("do something..");
		
	}

}

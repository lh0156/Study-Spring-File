package com.test.spring.di03;

public class BBB {

	public void run() {
		
		CCC c = new CCC();
		c.run();
		
	}

}

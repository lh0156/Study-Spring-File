package com.test.spring.di03;

public class CCC {

	public void run() {
		
		DDD d = new DDD();
		d.run();
		
	}

}
